# LivePlayerDemo
iOS 直播、点播播放器，支持rtmp、rtsp、flash、mp4等格式，直播延迟在3秒左右。技术讨论QQ群：282467670
